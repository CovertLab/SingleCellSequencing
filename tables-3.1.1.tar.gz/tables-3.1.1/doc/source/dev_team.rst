========================
PyTables Governance Team
========================

The PyTables team includes:

* Francesc Alted
* Ivan Vilata
* Scott Prater
* Vicent Mas
* Tom Hedley
* `Antonio Valentino`_
* Jeffrey Whitaker
* `Josh Moore`_
* `Anthony Scopatz`_

.. _Anthony Scopatz: http://www.scopatz.com/
.. _Antonio Valentino: https://github.com/avalentino
.. _Josh Moore: https://github.com/joshmoore
