==============================
 What's new in PyTables 1.3.3
==============================


:Author: Francesc Altet
:Contact: faltet@carabos.com
:Author: Ivan Vilata i Balaguer
:Contact: ivilata@carabos.com


This document details the modifications to PyTables since version 1.2.  Its
main purpose is help you ensure that your programs will be runnable when you
switch from PyTables 1.2 to PyTables 1.3.3.


API additions
=============

- None

Backward-incompatible changes
=============================

- None


Deprecated features
===================

- None


API refinements
===============

- None


Bug fixes (affecting API)
=========================

- None


----

  **Enjoy data!**

  -- The PyTables Team


.. Local Variables:
.. mode: text
.. coding: utf-8
.. fill-column: 78
.. End:
